#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/i2c.h>
#include <stdio.h>
#include <bme680_reg.h>

#define BME680_ADDR 0x77
#define MY_STACK_SIZE 5000
#define DELAY_MS 50

uint8_t container1 = 0;
uint8_t container2 = 0;
uint8_t container3 = 0;

uint32_t container = 0;

const struct device *i2c_dev = DEVICE_DT_GET(DT_NODELABEL(i2c0));

void read_task()
{
    printf("debug\n");
    while (1)
    {
        k_sleep(K_MSEC(3000));

        i2c_reg_write_byte(i2c_dev, BME680_ADDR, BME680_CTRL_MEAS, 0b101 << 5 | 0b01);
        i2c_reg_read_byte(i2c_dev, BME680_ADDR, BME680_TEMP_MSB, &container1);
        i2c_reg_read_byte(i2c_dev, BME680_ADDR, BME680_TEMP_LSB, &container2);
        i2c_reg_read_byte(i2c_dev, BME680_ADDR, BME680_TEMP_XLSB, &container3);
        uint8_t container4 = 0;
        while (!(container4 & 0b10000000))
        {
            i2c_reg_read_byte(i2c_dev, BME680_ADDR, BME680_EAS_STATUS_0, &container4);
            printf("not finished!\n");
        }
        printf("temp_msb:0x%x,temp_lsb:0x%x,temp_xlsb:0x%x\n", container1, container2, container3);
        container = (container3 >> 4) | (container2 << 4) | (container1 << 12);
        printf("temperature adc is 0x%x\n", container);
    }
}

int main(void)
{

    if (i2c_dev == NULL || !device_is_ready(i2c_dev))
    {

        printf("Could not get I2C device\n");
        return 0;
    }
    int ret1 = i2c_configure(i2c_dev, I2C_MODE_CONTROLLER | I2C_SPEED_SET(I2C_SPEED_STANDARD));
    if (ret1 < 0)
    {
        printf("error\n");
        return 0;
    }

    return 0;

    /* Read the Who Am I register */
}
K_THREAD_DEFINE(Task1, MY_STACK_SIZE, read_task, DELAY_MS, NULL, NULL, 1, 0, 0);
